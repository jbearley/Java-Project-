/* Aurthor: Jacob Earley
 * ID: 100367134
 * Date: 2/2/21
 * Description: This program prints out the message "Hello World" to Console
 */
public class HelloWorld 
{
	public static void main(String[]arg) 
	{
		System.out.println("Hello World");
	}
}
